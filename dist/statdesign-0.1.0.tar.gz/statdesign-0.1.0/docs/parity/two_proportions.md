# Parity Table

Scenario | Reference n1 | statdesign n1 | Reference n2 | statdesign n2
--- | --- | --- | --- | ---
p1=0.6, p2=0.5, exact=False | 389 | 389 | 389 | 389
p1=0.7, p2=0.6, exact=False | 404 | 404 | 606 | 606
p1=0.45, p2=0.5, exact=False | 1613 | 1613 | 1291 | 1291
p1=0.6, p2=0.58, exact=False | 1038 | 12709 | 1038 | 12709
