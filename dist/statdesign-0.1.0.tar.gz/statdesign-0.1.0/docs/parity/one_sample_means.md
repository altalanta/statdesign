# Parity Table

Scenario | Reference n | statdesign n
--- | --- | ---
Δ=0.5, σ=1.0, test=t | 34 | 34
Δ=0.4, σ=0.9, test=z | 37 | 37
