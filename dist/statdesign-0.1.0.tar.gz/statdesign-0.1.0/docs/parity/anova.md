# Parity Table

Scenario | Reference n | statdesign n
--- | --- | ---
k=4, f=0.25 | 180 | 202
k=3, f=0.35, weights=1,1,2 | 132 | 143
