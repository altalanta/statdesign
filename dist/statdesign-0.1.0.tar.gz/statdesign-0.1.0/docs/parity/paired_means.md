# Parity Table

Scenario | Reference n | statdesign n
--- | --- | ---
Δ=0.5, σ_d=1.0 | 34 | 34
