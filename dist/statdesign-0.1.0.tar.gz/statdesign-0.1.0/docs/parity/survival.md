# Parity Table

Scenario | Reference events | statdesign events
--- | --- | ---
HR=0.7, allocation=0.5 | 246.787 | 246.787
HR=0.8, allocation=0.6 | 879.258 | 879.258
HR=1.3, allocation=0.5 | 417.77 | 417.77
