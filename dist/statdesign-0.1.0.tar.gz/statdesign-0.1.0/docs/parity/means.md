# Parity Table

Scenario | Reference n1 | statdesign n1 | Reference n2 | statdesign n2
--- | --- | --- | --- | ---
μ1=0.0, μ2=0.5, σ=1.0, test=t | 64 | 64 | 64 | 64
μ1=1.0, μ2=1.3, σ=0.8, test=z | 155 | 155 | 233 | 233
